﻿// ReSharper disable CheckNamespace
namespace Caliburn.Micro.Logging // ReSharper restore CheckNamespace
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Implementation of the ILog and ILogExtended interfaces using
    /// <see cref="Debug"/>.
    /// </summary>
    public class DebugLogger : ILog, ILogExtended
    {
        #region Constants
        /// <summary>
        /// Error text
        /// </summary>
        private const string ErrorText = "ERROR";

        /// <summary>
        /// Warning text
        /// </summary>
        private const string WarnText = "WARN";

        /// <summary>
        /// Info text
        /// </summary>
        private const string InfoText = "INFO";

        #endregion

        #region Fields

        /// <summary>
        /// The type.
        /// </summary>
        private readonly Type type;

        #endregion

        #region Constructors

        /// <summary>
        /// Debug logger
        /// </summary>
        /// <param name="type">type</param>
        public DebugLogger(Type type)
        {
            this.type = type;
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Create log message
        /// </summary>
        /// <param name="format"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        private string CreateLogMessage(string format, params object[] args)
        {
            return string.Format("[{0}] {1}", DateTime.Now.ToString("o"), string.Format(format, args));
        }

        #endregion

        #region ILog Members

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        public void Error(Exception exception)
        {
            Debug.WriteLine(CreateLogMessage(exception.ToString()), ErrorText);
        }

        /// <summary>
        /// Logs the message as info.
        /// </summary>
        /// <param name="format">A formatted message.</param><param name="args">Parameters to be injected into the formatted message.</param>
        public void Info(string format, params object[] args)
        {
            Debug.WriteLine(CreateLogMessage(format, args), InfoText);
        }

        /// <summary>
        /// Logs the message as a warning.
        /// </summary>
        /// <param name="format">A formatted message.</param><param name="args">Parameters to be injected into the formatted message.</param>
        public void Warn(string format, params object[] args)
        {
            Debug.WriteLine(CreateLogMessage(format, args), WarnText);
        }

        #endregion

        #region Implementation of ILogExtended

        /// <summary>
        /// Logs the message as error.
        /// </summary>
        /// <param name="format">A formatted message.</param>
        /// <param name="args">Parameters to be injected into the formatted message.</param>
        public void Error(string format, params object[] args)
        {
            Debug.WriteLine(CreateLogMessage(format, args), ErrorText);
        }

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="format">A formatted message.</param>
        /// <param name="args">Parameters to be injected into the formatted message.</param>
        public void Error(Exception exception, string format, params object[] args)
        {
            Debug.WriteLine(CreateLogMessage(format + " - Exception = " + exception.ToString(), args), ErrorText);
        }

        #endregion
    }
}